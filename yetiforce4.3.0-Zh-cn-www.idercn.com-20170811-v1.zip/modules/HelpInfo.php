<?php
/**
 * HelpInfo 简体中文语言包
 * @package www.idercn.com
 * @版权所有 www.idercn.com
 * @license YetiForce Public License 3.0 (licenses/LicenseEN.txt or yetiforce.com)
 * @作者 www.idercn.com <idmaster@163.com>
 */
$languageStrings = [
	'Announcements|FL_INTERVAL' => '如果用户没有查看变更，则每天提醒。如果没有变更,提醒则不会再次显示。',
	'Accounts|Account Name' => '此字段用于公司名称',
];
