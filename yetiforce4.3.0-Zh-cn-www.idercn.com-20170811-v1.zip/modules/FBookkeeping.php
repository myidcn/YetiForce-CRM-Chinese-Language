<?php
/**
 * FBookkeeping 简体中文语言包
 * @package www.idercn.com
 * @版权所有 www.idercn.com
 * @license YetiForce Public License 3.0 (licenses/LicenseEN.txt or yetiforce.com)
 * @作者 www.idercn.com <idmaster@163.com>
 */
$languageStrings = [
	'FBookkeeping' => '记账本',
	'SINGLE_FBookkeeping' => '记账本',
	'FBookkeeping ID' => '记账本编号',
	'FL_SUBJECT' => '记账本标题',
];
