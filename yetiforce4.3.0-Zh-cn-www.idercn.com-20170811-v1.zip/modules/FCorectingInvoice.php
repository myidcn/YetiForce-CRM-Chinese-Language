<?php
/**
 * FCorectingInvoice 简体中文语言包
 * @package www.idercn.com
 * @版权所有 www.idercn.com
 * @license YetiForce Public License 3.0 (licenses/LicenseEN.txt or yetiforce.com)
 * @作者 www.idercn.com <idmaster@163.com>
 */
$languageStrings = [
	'FCorectingInvoice' => '正式发票',
	'SINGLE_FCorectingInvoice' => '正式发票',
	//BLOCKS
	'LBL_CUSTOM_INFORMATION' => '系统信息',
	'LBL_INVOICE_ADDRESS' => '发票地址',
	'LBL_ADDRESS_DELIVERY_INFORMATION' => '收信人地址',
	//FIELDS
	'FL_SUBJECT' => '标题',
	'FL_PAYMENT_DATE' => '截止日期',
	'FL_SALE_DATE' => '销售日期',
	'FL_FORM_PAYMENT' => '付款方式',
	'FL_BANK_ACCOUNT' => '银行账号',
	'FL_NUMBER' => '发票号码',
	'FL_ACCOUNT' => '客户',
	'FL_TOTAL' => '净总额',
	'FL_GROSS' => '毛总额',
	'FL_STATUS' => '状态',
	//PICKLIST VALUES
	'PLL_TRANSFER' => '转账',
	'PLL_CASH' => '现金',
	//OTHERS
	'LBL_YEAR' => '年',
	'FL_INVOICE' => '付款通知单',
];
