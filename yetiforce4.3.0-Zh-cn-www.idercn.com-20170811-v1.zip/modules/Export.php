<?php
/**
 * Export 简体中文语言包
 * @package www.idercn.com
 * @版权所有 www.idercn.com
 * @license YetiForce Public License 3.0 (licenses/LicenseEN.txt or yetiforce.com)
 * @作者 www.idercn.com <idmaster@163.com>
 */
$languageStrings = [
	'Export' => '导出',
	'LBL_INFO_USER_EXPORT_RECORDS' => "只能导出可用用户",
];
