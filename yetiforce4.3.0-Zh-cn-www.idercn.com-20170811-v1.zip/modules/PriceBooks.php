<?php
/* +***********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 * Contributor(s): YetiForce.com
 * ********************************************************************************** */
$languageStrings = [
	'LBL_ADD_TO' => '添加到',
	'LBL_EDIT_LIST_PRICE' => '编辑价格表',
	'LBL_PRICEBOOK_INFORMATION' => '价格表详情',
	'LBL_UNIT_PRICE' => '单价',
	'Price Book Name' => '价格表名称',
	'PriceBook No' => '价格表编号',
	'PriceBooks' => '价格表',
	'SINGLE_PriceBooks' => '价格表',
	'yes' => '是',
	'no' => '否',
	'Unit Price' => '单价',
];
