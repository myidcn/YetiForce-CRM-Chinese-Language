<?php
/**
 * CustomView 简体中文语言包
 * @package www.idercn.com
 * @版权所有 www.idercn.com
 * @license YetiForce Public License 3.0 (licenses/LicenseEN.txt or yetiforce.com)
 * @作者 www.idercn.com <idmaster@163.com>
 */
$languageStrings = [
	'CustomView' => '筛选视图-配置',
	'LBL_FEATURED' => '添加到收藏夹',
	'LBL_COLOR_VIEW' => '视图颜色',
];
